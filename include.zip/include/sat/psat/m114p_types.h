// C-language header for MiniSat 1.14p

#ifndef ABC__sat__psat__m114p_types_h
#define ABC__sat__psat__m114p_types_h


ABC_NAMESPACE_HEADER_START

typedef int   M114p_Solver_t;

ABC_NAMESPACE_HEADER_END

#endif
